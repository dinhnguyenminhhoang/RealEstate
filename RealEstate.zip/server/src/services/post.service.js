"use strict";

const { NotFoundError, AuthFailureError } = require("../core/error.response");
const { Post } = require("../models/post.model");
const { unGetSelectData } = require("../utils");

const { paginate } = require("../utils/paginate");

class PostService {
  static userCreateNewPost = async (data, userId) => {
    const {
      title,
      address,
      category,
      description,
      overview,
      price,
      images,
      acreage,
    } = data;
    if (!title || !address || !description || !price) {
      throw new NotFoundError("Missing parametor");
    }
    const post = await Post.create({
      title,
      address,
      description,
      author: userId,
      category: category,
      overview,
      price,
      images,
      acreage,
    });
    if (post._id) {
      return "Create success";
    }
  };
  static getAllPostByUser = async (
    {
      limit = 10,
      page = 1,
      filters = { isDelete: "active" },
      options,
      ...query
    },
    user
  ) => {
    if (!user) {
      throw new AuthFailureError("can't not find user");
    }
    filters = { ...filters, author: user.userId };
    let posts = await paginate({
      model: Post,
      limit: +limit,
      page: +page,
      filters,
      options,
      projection: unGetSelectData(["isDelete", "__v"]),
      // populate: ["author"],
    });

    return posts;
  };
  static getAllPost = async ({
    limit = 10,
    page = 1,
    filters,
    options,
    ...query
  }) => {
    filters = { ...filters, isDelete: "active" };
    let postes = await paginate({
      model: Post,
      limit: +limit,
      page: +page,
      filters,
      options,
      projection: unGetSelectData(["isDelete", "__v"]),
      populate: {
        path: "author",
        select: "userName email phone address _id",
      },
    });

    return postes;
  };
  static getPostDetail = async ({ id }) => {
    const filters = {
      _id: id,
      isDelete: "active",
    };

    const post = await Post.findOne(filters)
      .populate([
        {
          path: "author",
          select: "userName email phone address _id avatar",
        },
        {
          path: "category",
          select: "name _id",
        },
      ])
      .select(unGetSelectData(["__v", "isDelete", "verification"]));

    if (!post) {
      throw new NotFoundError("Post not found or has been deleted");
    }

    return post;
  };
  static getPostOutstanding = async ({ limit = 8 } = {}) => {
    const posts = await Post.find({ isDelete: "active" })
      .sort({ views: -1 })
      .limit(+limit)
      .select(unGetSelectData(["isDelete", "__v"]))
      .populate([
        {
          path: "author",
          select: "userName email phone address _id",
        },
        {
          path: "category",
          select: "name _id",
        },
      ])
      .lean();

    return posts;
  };
  static userGetYourPost = async (user, id) => {
    const isExist = await Post.findOne({ _id: id, author: user.userId });

    if (!isExist) {
      throw new NotFoundError("Post not found!");
    }
    return isExist;
  };
  static userUpdateYourPost = async (payload, user, id) => {
    const isExist = await Post.findOne({ _id: id, author: user.userId });

    if (!isExist) {
      throw new NotFoundError("Post not found!");
    }

    const result = await Post.findOneAndUpdate({ _id: id }, payload, {
      new: true,
    });
    return result;
  };
  static confirmPost = async (id) => {
    const isExist = await Post.findOne({ _id: id });

    if (!isExist) {
      throw new NotFoundError("Post not found!");
    }

    const result = await Post.findOneAndUpdate(
      { _id: id },
      { verification: !isExist.verification },
      {
        new: true,
      }
    );
    return result;
  };
  static userDeleteYourPost = async (user, id) => {
    const isExist = await Post.findOne({ _id: id, author: user.userId });

    if (!isExist) {
      throw new NotFoundError("Post not found!");
    }

    const result = await Post.findOneAndUpdate(
      { _id: id },
      { isDelete: "inActive" },
      {
        new: true,
      }
    );
    return result;
  };
  static deletePost = async (id) => {
    const isExist = await Post.findOne({ _id: id });

    if (!isExist) {
      throw new NotFoundError("Post not found!");
    }

    const result = await Post.findOneAndUpdate(
      { _id: id },
      { isDelete: "inActive" },
      {
        new: true,
      }
    );
    return result;
  };
}
module.exports = PostService;
